// Small helpers for the prototype (Bootstrap handles menus, modals and alerts).
document.addEventListener("DOMContentLoaded", function () {
  // 1. Ask before submitting forms that have a data-confirm message.
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      if (!window.confirm(form.dataset.confirm)) {
        event.preventDefault();
      }
    });
  });

  // 2. On the calendar form, the end date cannot be earlier than the start date.
  var start = document.getElementById("start_date");
  var end = document.getElementById("end_date");
  if (start && end) {
    start.addEventListener("change", function () {
      end.min = start.value;
      if (end.value && end.value < start.value) {
        end.value = "";
      }
    });
  }
});
