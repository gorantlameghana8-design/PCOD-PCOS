"""
Cycle analysis and the rule-based PCOS *screening* score.

Everything here is plain Python with no machine learning, so every point in
the score can be explained to the user. This is an educational estimate, NOT
a medical diagnosis.
"""

NORMAL_MIN = 21          # cycles shorter than this are "short"
NORMAL_MAX = 35          # cycles longer than this are "long"
VARIATION_LIMIT = 9      # if longest - shortest cycle is more than this many days -> "variation"
MIN_CYCLES_FOR_STATUS = 2
MAX_SCORE = 10

# Questionnaire definition: used by the form, the scoring and the PDF report.
QUESTIONS = [
    {"field": "irregular_periods", "label": "Irregular periods",
     "hint": "Periods that come at unpredictable times or are often skipped", "points": 2},
    {"field": "acne", "label": "Acne",
     "hint": "Frequent or persistent breakouts", "points": 1},
    {"field": "excess_hair", "label": "Excess facial or body hair",
     "hint": "Darker or thicker hair on the face, chest or back", "points": 1},
    {"field": "hair_loss", "label": "Hair thinning or hair loss",
     "hint": "Noticeable thinning on the scalp", "points": 1},
    {"field": "weight_change", "label": "Unexplained weight changes",
     "hint": "Weight gain or loss without a change in diet or activity", "points": 1},
    {"field": "dark_skin", "label": "Darkened skin patches",
     "hint": "Often on the neck, underarms or groin", "points": 1},
    {"field": "pelvic_discomfort", "label": "Pelvic discomfort",
     "hint": "Ongoing aching or pressure in the lower abdomen", "points": 1},
]
CYCLE_PATTERN_POINTS = 2   # awarded when the calendar shows frequent long/short cycles


# ---------------------------------------------------------------- cycles
def get_cycle_lengths(periods):
    """Cycle length = this period's start date - previous period's start date."""
    starts = sorted(p.start_date for p in periods)
    return [(b - a).days for a, b in zip(starts, starts[1:])]


def classify_cycle(days):
    """Label a single cycle length as Normal / Short / Long."""
    if days < NORMAL_MIN:
        return {"label": "Short", "css": "warning"}
    if days > NORMAL_MAX:
        return {"label": "Long", "css": "warning"}
    return {"label": "Normal", "css": "success"}


def detect_cycle_irregularity(periods):
    """
    Analyse recorded periods and return a dictionary with:
    average / minimum / maximum cycle length, number of cycles, a regularity
    status (code + text), a short explanation and an estimated next period.
    """
    periods = sorted(periods, key=lambda p: p.start_date)
    lengths = get_cycle_lengths(periods)

    info = {
        "num_periods": len(periods),
        "num_cycles": len(lengths),
        "lengths": lengths,
        "average": None, "minimum": None, "maximum": None,
        "out_of_range": 0,
        "status_code": "not_enough_data",
        "status": "Not enough data yet",
        "explanation": "Add at least 3 period start dates (2 cycles) to see a regularity result.",
        "next_period": None,
        "avg_duration": 5,
    }

    # Average bleeding length (only for periods that have an end date)
    durations = [(p.end_date - p.start_date).days + 1 for p in periods if p.end_date]
    if durations:
        info["avg_duration"] = max(1, round(sum(durations) / len(durations)))

    if not lengths:
        return info

    average = sum(lengths) / len(lengths)
    info["average"] = round(average, 1)
    info["minimum"] = min(lengths)
    info["maximum"] = max(lengths)
    info["out_of_range"] = sum(1 for d in lengths if d < NORMAL_MIN or d > NORMAL_MAX)

    # Next Period = Last Period Start Date + Average Cycle Length (an estimate only)
    from datetime import timedelta
    info["next_period"] = periods[-1].start_date + timedelta(days=round(average))

    if len(lengths) < MIN_CYCLES_FOR_STATUS:
        return info

    spread = info["maximum"] - info["minimum"]
    n = len(lengths)

    if info["out_of_range"] * 2 >= n:               # half or more cycles outside 21-35 days
        info["status_code"] = "irregular"
        info["status"] = "Irregular cycle pattern detected"
        info["explanation"] = (f"{info['out_of_range']} of your {n} recorded cycles were shorter "
                               f"than {NORMAL_MIN} or longer than {NORMAL_MAX} days.")
    elif spread > VARIATION_LIMIT:                  # lengths jump around a lot
        info["status_code"] = "variation"
        info["status"] = "Cycle length variation detected"
        info["explanation"] = (f"Your shortest cycle was {info['minimum']} days and your longest was "
                               f"{info['maximum']} days, a difference of {spread} days.")
    elif NORMAL_MIN <= average <= NORMAL_MAX:
        info["status_code"] = "regular"
        info["status"] = "Cycle appears relatively regular"
        info["explanation"] = (f"Your cycles average {info['average']} days and are similar in length.")
    else:
        info["status_code"] = "irregular"
        info["status"] = "Irregular cycle pattern detected"
        info["explanation"] = f"Your average cycle of {info['average']} days is outside the usual {NORMAL_MIN}-{NORMAL_MAX} day range."
    return info


# ---------------------------------------------------------------- score
CATEGORIES = {
    "low": {
        "key": "low", "label": "Lower screening indicators", "css": "low",
        "meaning": ("Your responses show few of the signs that are sometimes associated with PCOS. "
                    "This is only a screening estimate. If you are worried about your cycles or "
                    "symptoms, a healthcare professional can always help."),
    },
    "moderate": {
        "key": "moderate", "label": "Moderate screening indicators", "css": "moderate",
        "meaning": ("Your responses include some symptoms that can sometimes be associated with PCOS. "
                    "This result does not mean that you have PCOS. A healthcare professional can "
                    "evaluate your symptoms and medical history."),
    },
    "higher": {
        "key": "higher", "label": "Higher screening indicators", "css": "higher",
        "meaning": ("Your responses include several symptoms that can sometimes be associated with PCOS. "
                    "This does not mean that you have PCOS, since many conditions share these signs. "
                    "Consider sharing this summary with a healthcare professional who can guide next steps."),
    },
}


def get_category(score):
    """0-2 lower, 3-5 moderate, 6+ higher."""
    if score <= 2:
        return CATEGORIES["low"]
    if score <= 5:
        return CATEGORIES["moderate"]
    return CATEGORIES["higher"]


def calculate_pcos_score(symptom, cycle_info):
    """
    Add up transparent points. Returns None if the questionnaire has not been done.
    `factors` lists every rule that added points, so the result page can explain it.
    """
    if symptom is None:
        return None

    factors = []
    for q in QUESTIONS:
        if getattr(symptom, q["field"]):
            factors.append({"label": q["label"], "points": q["points"]})

    if cycle_info and cycle_info["status_code"] == "irregular":
        factors.append({"label": "Frequent long or short cycles (from your calendar)",
                        "points": CYCLE_PATTERN_POINTS})

    score = sum(f["points"] for f in factors)
    category = get_category(score)
    return {"score": score, "max_score": MAX_SCORE, "category": category, "factors": factors}


def symptom_answers(symptom):
    """(question, 'Yes'/'No') pairs for the report and the summary tables."""
    if symptom is None:
        return []
    return [(q["label"], "Yes" if getattr(symptom, q["field"]) else "No") for q in QUESTIONS]
