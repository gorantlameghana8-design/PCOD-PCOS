"""Doctor report PDF, built with ReportLab. Kept separate from app.py on purpose."""
import io
from datetime import date
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from risk_engine import classify_cycle, symptom_answers

PLUM = colors.HexColor("#5b3a8c")
LILAC = colors.HexColor("#efe9f8")
GREY = colors.HexColor("#6b6480")

FOOTER_TEXT = ("This report is generated from user-provided information and is intended to support "
               "discussion with a healthcare professional. It is not a medical diagnosis.")
SCORE_NOTE = ("This score is only an educational screening estimate. It cannot diagnose PCOS. "
              "Please consult a qualified healthcare professional for medical evaluation.")


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=base["Title"], textColor=PLUM, fontSize=20, alignment=0, spaceAfter=2),
        "sub": ParagraphStyle("s", parent=base["Normal"], textColor=GREY, fontSize=10),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], textColor=PLUM, fontSize=13, spaceBefore=14, spaceAfter=6),
        "body": ParagraphStyle("b", parent=base["Normal"], fontSize=10, leading=14),
        "note": ParagraphStyle("n", parent=base["Normal"], fontSize=9, leading=12, textColor=GREY),
    }


def _table(rows, widths, header=True):
    table = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    style = [
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d9d2e9")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), PLUM),
                  ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                  ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
    else:
        style += [("BACKGROUND", (0, 0), (0, -1), LILAC),
                  ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold")]
    table.setStyle(TableStyle(style))
    return table


def _footer(canvas, doc):
    """Drawn at the bottom of every page."""
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(GREY)
    canvas.drawString(2 * cm, 1.3 * cm, FOOTER_TEXT)
    canvas.drawRightString(A4[0] - 2 * cm, 0.8 * cm, f"Page {doc.page}")
    canvas.restoreState()


def build_doctor_report(user, periods, cycle_info, symptom, screening):
    """Return the PDF as a BytesIO. `screening` is the dict from calculate_pcos_score (or None)."""
    s = _styles()
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=2.2 * cm,
                            title="Menstrual & PCOS Screening Summary", author="Hackathon prototype")
    story = [
        Paragraph("AI-Based Smart Menstrual &amp; PCOS Risk System", s["title"]),
        Paragraph("Health summary for discussion with a healthcare professional", s["sub"]),
        Spacer(1, 6), HRFlowable(width="100%", color=PLUM, thickness=1.2),
    ]

    # --- patient details
    story.append(Paragraph("Patient details", s["h2"]))
    story.append(_table([
        ["Name", escape(user.name)],
        ["Age", str(user.age)],
        ["Report date", date.today().strftime("%d %B %Y")],
    ], [4 * cm, 13 * cm], header=False))

    # --- cycle summary
    story.append(Paragraph("Menstrual cycle summary", s["h2"]))
    avg = f"{cycle_info['average']} days" if cycle_info["average"] else "Not enough data"
    mn = f"{cycle_info['minimum']} days" if cycle_info["minimum"] else "-"
    mx = f"{cycle_info['maximum']} days" if cycle_info["maximum"] else "-"
    story.append(_table([
        ["Periods recorded", str(cycle_info["num_periods"])],
        ["Cycles measured", str(cycle_info["num_cycles"])],
        ["Average cycle length", avg],
        ["Shortest / longest cycle", f"{mn} / {mx}"],
        ["Cycle regularity", escape(cycle_info["status"])],
    ], [6 * cm, 11 * cm], header=False))
    story.append(Spacer(1, 4))
    story.append(Paragraph(escape(cycle_info["explanation"]), s["note"]))

    # --- recorded periods
    story.append(Paragraph("Recorded period dates", s["h2"]))
    if periods:
        rows = [["Start date", "End date", "Cycle length", "Pattern"]]
        prev = None
        for p in sorted(periods, key=lambda x: x.start_date):
            length = (p.start_date - prev.start_date).days if prev else None
            rows.append([
                p.start_date.strftime("%d %b %Y"),
                p.end_date.strftime("%d %b %Y") if p.end_date else "-",
                f"{length} days" if length else "-",
                classify_cycle(length)["label"] if length else "-",
            ])
            prev = p
        story.append(_table(rows, [4.5 * cm, 4.5 * cm, 4 * cm, 4 * cm]))
    else:
        story.append(Paragraph("No periods have been recorded.", s["body"]))

    # --- questionnaire
    story.append(Paragraph("Questionnaire responses", s["h2"]))
    answers = symptom_answers(symptom)
    if answers:
        story.append(_table([["Symptom", "Response"]] + [[q, a] for q, a in answers], [12 * cm, 5 * cm]))
    else:
        story.append(Paragraph("The symptom questionnaire has not been completed.", s["body"]))

    # --- screening
    story.append(Paragraph("PCOS risk screening score", s["h2"]))
    if screening:
        story.append(_table([
            ["Screening score", f"{screening['score']} / {screening['max_score']}"],
            ["Screening category", screening["category"]["label"]],
        ], [6 * cm, 11 * cm], header=False))
        story.append(Spacer(1, 6))
        story.append(Paragraph("<b>Main contributing factors</b>", s["body"]))
        if screening["factors"]:
            rows = [["Factor", "Points"]] + [[escape(f["label"]), f"+{f['points']}"] for f in screening["factors"]]
            story.append(Spacer(1, 3))
            story.append(_table(rows, [13 * cm, 4 * cm]))
        else:
            story.append(Paragraph("No contributing factors were selected.", s["body"]))
    else:
        story.append(Paragraph("A screening score is not available until the questionnaire is completed.", s["body"]))

    # --- disclaimers
    story.append(Spacer(1, 14))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#d9d2e9")))
    story.append(Spacer(1, 6))
    story.append(Paragraph("<b>Disclaimer.</b> " + SCORE_NOTE, s["body"]))
    story.append(Spacer(1, 6))
    story.append(Paragraph(FOOTER_TEXT, s["note"]))

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    buffer.seek(0)
    return buffer
