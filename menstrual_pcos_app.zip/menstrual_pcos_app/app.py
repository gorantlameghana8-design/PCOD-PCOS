"""
AI-Based Smart Menstrual & PCOS Risk System  (hackathon prototype)

Educational risk screening only - NOT a medical diagnosis.
Run with:  python app.py   then open http://127.0.0.1:5000
"""
import calendar as pycal
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta, timezone
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from models import Period, RiskResult, Symptom, User, db
from report_generator import build_doctor_report
from risk_engine import (QUESTIONS, calculate_pcos_score, classify_cycle,
                         detect_cycle_irregularity, get_category, symptom_answers)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
# Change SECRET_KEY (environment variable) for anything beyond a local demo.
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "menstrual.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

db.init_app(app)
with app.app_context():
    db.create_all()  # creates menstrual.db and the tables on first run

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
DEMO_EMAIL = "demo@example.com"
DEMO_PASSWORD = "demo1234"


# ------------------------------------------------------------ security helpers
@app.before_request
def csrf_protect():
    """Very small CSRF check: every POST form must carry the session's token."""
    if request.method == "POST":
        token = session.get("_csrf")
        if not token or token != request.form.get("_csrf"):
            flash("Your session expired. Please try again.", "warning")
            return redirect(request.referrer or url_for("login"))


@app.context_processor
def inject_csrf():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return {"csrf_token": session["_csrf"]}


@app.before_request
def load_user():
    """Make the logged-in user available as g.user on every request."""
    g.user = None
    user_id = session.get("user_id")
    if user_id:
        g.user = db.session.get(User, user_id)
        if g.user is None:            # account was deleted
            session.pop("user_id", None)


def login_required(view):
    """Protect a page so only logged-in users can open it."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in to continue.", "info")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


# ------------------------------------------------------------ data helpers
def parse_date(text):
    try:
        return datetime.strptime((text or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def get_periods(user_id):
    return Period.query.filter_by(user_id=user_id).order_by(Period.start_date).all()


def latest_symptom(user_id):
    return (Symptom.query.filter_by(user_id=user_id)
            .order_by(Symptom.created_at.desc(), Symptom.id.desc()).first())


def latest_result(user_id):
    return (RiskResult.query.filter_by(user_id=user_id)
            .order_by(RiskResult.created_at.desc(), RiskResult.id.desc()).first())


def refresh_risk_result(user):
    """
    Recalculate the screening score from the latest questionnaire + calendar and
    save it as a RiskResult (only if something changed). Needs a questionnaire.
    """
    symptom = latest_symptom(user.id)
    if symptom is None:
        return None
    screening = calculate_pcos_score(symptom, detect_cycle_irregularity(get_periods(user.id)))
    factors_json = json.dumps(screening["factors"])
    last = latest_result(user.id)
    if last and last.score == screening["score"] and last.contributing_factors == factors_json:
        return last
    result = RiskResult(user_id=user.id, score=screening["score"],
                        category=screening["category"]["label"],
                        contributing_factors=factors_json)
    db.session.add(result)
    db.session.commit()
    return result


def build_period_rows(periods):
    """Table rows (newest first) with cycle length and Normal/Short/Long label."""
    rows, previous = [], None
    for p in periods:  # periods are sorted oldest -> newest
        length = (p.start_date - previous.start_date).days if previous else None
        rows.append({
            "period": p,
            "cycle_length": length,
            "status": classify_cycle(length) if length else None,
            "duration": (p.end_date - p.start_date).days + 1 if p.end_date else None,
        })
        previous = p
    return list(reversed(rows))


def create_sample_data(user):
    """Replace this user's data with fictional demo data (no real person's information)."""
    Period.query.filter_by(user_id=user.id).delete()
    Symptom.query.filter_by(user_id=user.id).delete()
    RiskResult.query.filter_by(user_id=user.id).delete()

    cycle_lengths = [40, 37, 44, 36, 41]          # oldest -> newest, mostly longer than 35 days
    starts = [date.today() - timedelta(days=12)]  # latest period started 12 days ago
    for length in reversed(cycle_lengths):
        starts.append(starts[-1] - timedelta(days=length))
    for start in reversed(starts):
        db.session.add(Period(user_id=user.id, start_date=start, end_date=start + timedelta(days=4)))

    db.session.add(Symptom(user_id=user.id, irregular_periods=True, acne=True, excess_hair=False,
                           hair_loss=False, weight_change=False, dark_skin=False,
                           pelvic_discomfort=False))
    db.session.commit()
    refresh_risk_result(user)


# ------------------------------------------------------------ auth routes
@app.route("/")
def index():
    return redirect(url_for("dashboard" if g.user else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard"))
    form = {}
    if request.method == "POST":
        form = request.form
        name = form.get("name", "").strip()
        email = form.get("email", "").strip().lower()
        password = form.get("password", "")
        age_text = form.get("age", "").strip()
        consented = form.get("consent") == "on"

        errors = []
        if len(name) < 2:
            errors.append("Please enter your name.")
        if not EMAIL_RE.match(email):
            errors.append("Please enter a valid email address.")
        elif User.query.filter_by(email=email).first():
            errors.append("An account with this email already exists.")
        if len(password) < 8:
            errors.append("Password must be at least 8 characters.")
        if not age_text.isdigit() or not (10 <= int(age_text) <= 100):
            errors.append("Please enter an age between 10 and 100.")
        if not consented:
            errors.append("You must accept the consent statement to register.")

        if errors:
            for message in errors:
                flash(message, "danger")
        else:
            user = User(name=name, email=email, age=int(age_text), consent=True,
                        password_hash=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear()
            session["user_id"] = user.id
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html", demo_email=DEMO_EMAIL)


@app.route("/demo-login", methods=["POST"])
def demo_login():
    """Hackathon shortcut: create/reset a demo account with fictional sample data and log in."""
    user = User.query.filter_by(email=DEMO_EMAIL).first()
    if user is None:
        user = User(name="Demo User", email=DEMO_EMAIL, age=24, consent=True,
                    password_hash=generate_password_hash(DEMO_PASSWORD))
        db.session.add(user)
        db.session.commit()
    create_sample_data(user)
    session.clear()
    session["user_id"] = user.id
    flash("Signed in to the demo account with fictional sample data.", "info")
    return redirect(url_for("dashboard"))


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ------------------------------------------------------------ main pages
@app.route("/dashboard")
@login_required
def dashboard():
    periods = get_periods(g.user.id)
    cycle_info = detect_cycle_irregularity(periods)
    result = latest_result(g.user.id)
    return render_template(
        "dashboard.html",
        last_period=periods[-1] if periods else None,
        cycle_info=cycle_info,
        result=result,
        category=get_category(result.score) if result else None,
    )


@app.route("/calendar")
@login_required
def calendar_view():
    periods = get_periods(g.user.id)
    cycle_info = detect_cycle_irregularity(periods)

    # Which month to draw (?month=YYYY-MM), default = this month
    today = date.today()
    year, month = today.year, today.month
    match = re.match(r"^(\d{4})-(\d{2})$", request.args.get("month", ""))
    if match and 1 <= int(match.group(2)) <= 12 and 1900 <= int(match.group(1)) <= 2100:
        year, month = int(match.group(1)), int(match.group(2))

    # Days to highlight: recorded period days and the estimated next period
    period_days = set()
    for p in periods:
        end = p.end_date or p.start_date
        for offset in range((end - p.start_date).days + 1):
            period_days.add(p.start_date + timedelta(days=offset))
    predicted_days = set()
    if cycle_info["next_period"]:
        for offset in range(cycle_info["avg_duration"]):
            predicted_days.add(cycle_info["next_period"] + timedelta(days=offset))

    weeks = []
    for week in pycal.Calendar(firstweekday=6).monthdatescalendar(year, month):
        weeks.append([{
            "date": d, "in_month": d.month == month, "today": d == today,
            "period": d in period_days,
            "predicted": d in predicted_days and d not in period_days,
        } for d in week])

    first = date(year, month, 1)
    prev_month = (first - timedelta(days=1)).strftime("%Y-%m")
    next_month = (first + timedelta(days=32)).strftime("%Y-%m")

    return render_template("calendar.html", rows=build_period_rows(periods), cycle_info=cycle_info,
                           weeks=weeks, month_label=first.strftime("%B %Y"),
                           prev_month=prev_month, next_month=next_month, today=today.isoformat())


@app.route("/add-period", methods=["GET", "POST"])
@login_required
def add_period():
    if request.method == "GET":
        return redirect(url_for("calendar_view") + "#add-period")

    start = parse_date(request.form.get("start_date"))
    end_text = request.form.get("end_date", "").strip()
    end = parse_date(end_text) if end_text else None

    if start is None:
        flash("Please enter a valid start date.", "danger")
    elif start > date.today():
        flash("The start date cannot be in the future.", "danger")
    elif end_text and end is None:
        flash("Please enter a valid end date, or leave it empty.", "danger")
    elif end and end < start:
        flash("The end date cannot be before the start date.", "danger")
    elif end and (end - start).days > 14:
        flash("A period longer than 15 days looks like a typing mistake. Please check the dates.", "danger")
    elif Period.query.filter_by(user_id=g.user.id, start_date=start).first():
        flash("You already recorded a period starting on that date.", "warning")
    else:
        db.session.add(Period(user_id=g.user.id, start_date=start, end_date=end))
        db.session.commit()
        refresh_risk_result(g.user)
        flash("Period saved.", "success")
    return redirect(url_for("calendar_view"))


@app.route("/delete-period/<int:period_id>", methods=["POST"])
@login_required
def delete_period(period_id):
    period = db.session.get(Period, period_id)
    if period is None or period.user_id != g.user.id:   # users can only delete their own rows
        abort(404)
    db.session.delete(period)
    db.session.commit()
    refresh_risk_result(g.user)
    flash("Period removed.", "info")
    return redirect(url_for("calendar_view"))


@app.route("/questionnaire", methods=["GET", "POST"])
@login_required
def questionnaire():
    previous = latest_symptom(g.user.id)
    answers = {q["field"]: ("yes" if getattr(previous, q["field"]) else "no")
               for q in QUESTIONS} if previous else {}

    if request.method == "POST":
        submitted = {q["field"]: request.form.get(q["field"]) for q in QUESTIONS}
        if any(value not in ("yes", "no") for value in submitted.values()):
            flash("Please answer every question with Yes or No.", "danger")
            answers = {k: v for k, v in submitted.items() if v in ("yes", "no")}
        else:
            db.session.add(Symptom(user_id=g.user.id,
                                   **{field: value == "yes" for field, value in submitted.items()}))
            db.session.commit()
            refresh_risk_result(g.user)
            flash("Thank you. Your screening result is ready.", "success")
            return redirect(url_for("risk_result"))
    return render_template("questionnaire.html", questions=QUESTIONS, answers=answers)


@app.route("/risk-result")
@login_required
def risk_result():
    result = latest_result(g.user.id)
    cycle_info = detect_cycle_irregularity(get_periods(g.user.id))
    if result is None:
        return render_template("result.html", result=None, cycle_info=cycle_info)
    return render_template(
        "result.html", result=result, cycle_info=cycle_info,
        category=get_category(result.score),
        factors=json.loads(result.contributing_factors),
        score_percent=min(100, result.score * 10),
    )


# ------------------------------------------------------------ doctor report
def report_data(user):
    periods = get_periods(user.id)
    cycle_info = detect_cycle_irregularity(periods)
    symptom = latest_symptom(user.id)
    return periods, cycle_info, symptom, calculate_pcos_score(symptom, cycle_info)


@app.route("/generate-report")
@login_required
def generate_report():
    """Preview page with a download button."""
    periods, cycle_info, symptom, screening = report_data(g.user)
    return render_template("report.html", periods=periods, cycle_info=cycle_info,
                           answers=symptom_answers(symptom), screening=screening,
                           today=date.today())


@app.route("/download-report")
@login_required
def download_report():
    periods, cycle_info, symptom, screening = report_data(g.user)
    pdf = build_doctor_report(g.user, periods, cycle_info, symptom, screening)
    return send_file(pdf, mimetype="application/pdf", as_attachment=True,
                     download_name=f"doctor_report_{date.today().isoformat()}.pdf")


# ------------------------------------------------------------ privacy + delete
@app.route("/privacy")
@login_required
def privacy():
    return render_template("privacy.html")


@app.route("/load-demo", methods=["POST"])
@login_required
def load_demo():
    create_sample_data(g.user)
    flash("Fictional sample data loaded. Your earlier records were replaced.", "info")
    return redirect(url_for("dashboard"))


@app.route("/delete-data", methods=["POST"])
@login_required
def delete_data():
    """Delete the account; cascade rules in models.py remove periods, symptoms and results."""
    db.session.delete(g.user)
    db.session.commit()
    session.clear()
    flash("Your account and all of your data have been permanently deleted.", "success")
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)
