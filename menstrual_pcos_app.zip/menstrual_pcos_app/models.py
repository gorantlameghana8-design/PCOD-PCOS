"""
Database models (SQLAlchemy via Flask-SQLAlchemy).

User is the parent record. Period, Symptom and RiskResult all belong to a
user, and cascade="all, delete-orphan" means deleting a User automatically
deletes all of their rows in those tables (used by "Delete My Data").
"""
from datetime import datetime, timezone

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


def utc_now():
    return datetime.now(timezone.utc)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)  # never store plain passwords
    age = db.Column(db.Integer, nullable=False)
    consent = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=utc_now)

    periods = db.relationship("Period", backref="user", cascade="all, delete-orphan")
    symptoms = db.relationship("Symptom", backref="user", cascade="all, delete-orphan")
    risk_results = db.relationship("RiskResult", backref="user", cascade="all, delete-orphan")


class Period(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)


class Symptom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    irregular_periods = db.Column(db.Boolean, default=False)
    acne = db.Column(db.Boolean, default=False)
    excess_hair = db.Column(db.Boolean, default=False)
    hair_loss = db.Column(db.Boolean, default=False)
    weight_change = db.Column(db.Boolean, default=False)
    dark_skin = db.Column(db.Boolean, default=False)
    pelvic_discomfort = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=utc_now)


class RiskResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    score = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(60), nullable=False)
    contributing_factors = db.Column(db.Text, nullable=False)  # JSON list of {label, points}
    created_at = db.Column(db.DateTime, default=utc_now)
