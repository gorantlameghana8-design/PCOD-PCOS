# AI-Based Smart Menstrual & PCOS Risk System

A beginner-friendly Flask web app built as a hackathon prototype. It helps a user track menstrual
cycles, record symptoms, spot cycle irregularities, and see a transparent, rule-based
**PCOS risk-screening estimate** with a plain-language explanation.

> **This is an educational prototype, not a medical diagnostic system. It cannot diagnose PCOS.**

## Features

- Registration with a required consent checkbox, login, logout (Flask sessions, hashed passwords)
- Dashboard: last period, average cycle length, regularity status, latest screening result
- Period calendar: add periods, month grid, history table with Normal / Short / Long cycle labels
- Estimated next period (`last start date + average cycle length`), clearly marked as an estimate
- Cycle irregularity detection (`detect_cycle_irregularity()` in `risk_engine.py`)
- 7-question Yes/No symptom questionnaire
- Explainable PCOS Risk Screening Score out of 10 with colour-coded categories
- "Doctor Report" preview and downloadable PDF (ReportLab)
- Privacy page and "Delete My Data" (removes account, periods, answers and results)
- One-click demo account and "Load sample data" with fictional data

## Technology stack

Python 3, Flask, SQLite, SQLAlchemy (via Flask-SQLAlchemy), Jinja2 templates, HTML5, CSS3,
Bootstrap 5 (loaded from a CDN), basic JavaScript, Werkzeug password hashing, ReportLab.

## Installation and run

```bash
pip install -r requirements.txt
python app.py
```

Then open <http://127.0.0.1:5000>.

Tip: use a virtual environment (`python -m venv venv`, then activate it) before `pip install`.
Bootstrap and the fonts load from the internet, so connect to Wi-Fi when demonstrating.

## Database setup

There is nothing to set up. The SQLite file `menstrual.db` and its tables are created
automatically the first time you run `python app.py`. Delete `menstrual.db` to start fresh.

## Demo instructions

1. On the login page click **Open the demo account**. This creates `demo@example.com`
   (password `demo1234`) filled with fictional cycles and symptoms.
2. Dashboard: cycle pattern shows as irregular and the score appears as **5/10, moderate screening indicators**.
3. Open **Calendar** (highlighted period days and estimated next period), **Risk Result**
   (the "Why did I get this result?" breakdown), then **Doctor Report** to download the PDF.
4. Finish with **Privacy** and **Delete My Data** to show the confirmation step.

To demo your own account, register normally. Once logged in, **Load sample data** on the dashboard
fills it with the same fictional data (it replaces existing records).

## How the score works

| Item | Points |
|---|---|
| Irregular periods (questionnaire) | +2 |
| Frequent long/short cycles (from your calendar) | +2 |
| Acne, excess hair, hair thinning, weight changes, darkened skin, pelvic discomfort | +1 each |

Maximum 10. Categories: 0-2 lower, 3-5 moderate, 6 and above higher screening indicators.
The brief listed no points for pelvic discomfort; it is worth +1 here so the maximum matches the "/10" display.
Cycle rules (in `risk_engine.py`): normal 21-35 days; "irregular" when half or more cycles fall outside
that range; "variation" when the longest and shortest cycles differ by more than 9 days.
At least 2 cycles (3 periods) are needed for a regularity status.

## Project structure

```
app.py               routes, validation, sessions
models.py            User, Period, Symptom, RiskResult
risk_engine.py       cycle analysis + rule-based score
report_generator.py  PDF report (ReportLab)
templates/           Jinja HTML pages
static/              CSS and JavaScript
```

## Limitations

- Not a diagnostic tool. The rules are simple, unvalidated, and were not reviewed by clinicians.
- The score ignores many relevant factors (hormone tests, ultrasound, medical history, medication).
- Cycle estimates are averages and can be wrong, especially with few records.
- Not production-ready: no email verification, password reset, rate limiting or HTTPS, and the
  default `SECRET_KEY` is for local use only (set the `SECRET_KEY` environment variable otherwise).
- Data is stored unencrypted in a local SQLite file. No legal or regulatory compliance
  (e.g. HIPAA or GDPR) is claimed, implemented or verified.
- Debug mode is on in `app.py` for convenience. Turn it off outside local demos.

## Medical disclaimer

This application provides an educational health-risk screening and is not a medical diagnosis.
It cannot diagnose PCOS or any other condition. Please consult a qualified healthcare professional
for medical evaluation. If you have severe pain, very heavy bleeding, or feel unwell, seek medical care.
